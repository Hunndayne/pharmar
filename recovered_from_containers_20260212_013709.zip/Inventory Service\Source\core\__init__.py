"""Core settings."""
