"""Inventory source package."""
